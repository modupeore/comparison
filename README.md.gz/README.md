Comparsion among different lines and tissues
